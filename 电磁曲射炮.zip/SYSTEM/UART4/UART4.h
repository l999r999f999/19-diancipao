#ifndef __UART4_H
#define __UART4_H


#include "sys.h"
extern u8 Rec_Buf[4];

void UART4_Init(u32 bound);


#endif


