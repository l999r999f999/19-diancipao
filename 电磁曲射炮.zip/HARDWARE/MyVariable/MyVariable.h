#ifndef __MY_VARIABLE_H
#define __MY_VARIABLE_H


extern int Num[21];
extern int Pwm[21];


#endif
