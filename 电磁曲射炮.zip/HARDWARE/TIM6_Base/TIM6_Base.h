#ifndef __TIM6_BASE_H
#define __TIM6_BASE_H

#include "sys.h"

void TIM6_Init(u16 arr,u16 psc);

#endif 

