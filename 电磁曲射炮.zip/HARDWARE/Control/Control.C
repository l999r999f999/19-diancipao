#include "control.h"
#include "delay.h"

int L = 0;
int Angle = -30;
int Pos = 0;

void Get_Pos(void)
{
	Pos = (int)(Rec_Buf[0]|(Rec_Buf[1]<<8));
}

void Get_Distance(void)
{
	L = (int)(Rec_Buf[2]|(Rec_Buf[3]<<8))-30;
}

void X_Control(void)
{
	int Pwm;
	Get_Pos();
	Pwm = M1_PID_Balance();
	
	static int temp;
	temp += Pwm;
	if(temp < 1427) temp = 1427;
	if(temp > 2093) temp = 2093;
//	Pwm = RangeM1(M1_PID_Balance());
	SetPWM1(temp);
}



int RangeM1(int pwm)
{
	if(pwm > 1000) pwm = 1000;
	if(pwm <-1000) pwm = -1000;
	return pwm;
}

void Beep_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;//PC2
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOC,&GPIO_InitStructure);
	
}

void Sound2(void)
{
	u8 t[]={10,8,6,4,2};
	for(int a=1;a<=5;a++)
	{
    BEEP = 1;
    delay_ms(5);
    BEEP = 0;
    delay_ms(t[a]);
	}
}

