#ifndef __AnoTc_H
#define __AnoTc_H

#include "sys.h"

void TestSendData(u8 *dataToSend , u8 length);
void Test_Send_User(u16 data1);

#endif

